package ru.terrakino.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.Environment;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;

import com.chaquo.python.Python;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;

/** Держит Python-сервер живым, пока приложение свёрнуто (нужно для фонового скачивания серий). */
public class ServerService extends Service {
    static volatile boolean ready = false;
    static volatile String error = "";
    static volatile String root = "";
    private boolean started = false;
    private final Handler h = new Handler(Looper.getMainLooper());
    private PowerManager.WakeLock wl;

    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            new Thread(() -> {
                boolean busy = false;
                try {
                    if (ready) {
                        busy = Python.getInstance().getModule("runner").callAttr("busy").toBoolean();
                    }
                } catch (Throwable ignored) {
                }
                final boolean b = busy;
                h.post(() -> {
                    if (wl == null) return;
                    if (b) wl.acquire(60000);
                    else if (wl.isHeld()) wl.release();
                });
            }).start();
            h.postDelayed(this, 15000);
        }
    };

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        Notification n = buildNotification();
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC);
        } else {
            startForeground(1, n);
        }
        if (!started) {
            started = true;
            PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
            wl = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "terrakino:downloads");
            wl.setReferenceCounted(false);
            h.postDelayed(tick, 15000);
            new Thread(() -> {
                try {
                    copyAssets();
                    File lib = libraryRoot(ServerService.this);
                    root = lib.getAbsolutePath();
                    Python.getInstance().getModule("runner").callAttr(
                            "start", root, getFilesDir().getAbsolutePath(), MainActivity.PORT);
                    ready = true;
                } catch (Throwable t) {
                    error = String.valueOf(t);
                }
            }, "terra-start").start();
        }
        return START_NOT_STICKY;
    }

    /** Есть ли доступ ко всем файлам: тогда видео из «Загрузок» не копируются, а переносятся. */
    static boolean hasAllFiles(Context c) {
        if (Build.VERSION.SDK_INT >= 30) return Environment.isExternalStorageManager();
        return c.checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED;
    }

    /** Папка библиотеки: Terrakino во внутренней памяти (быстрый перенос) или папка приложения. */
    static File libraryRoot(Context c) {
        if (hasAllFiles(c)) {
            File r = new File(Environment.getExternalStorageDirectory(), "Terrakino");
            if (r.isDirectory() || r.mkdirs()) return r;
        }
        File d = c.getExternalFilesDir(null);
        return d != null ? d : c.getFilesDir();
    }

    private Notification buildNotification() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel("terra", "Терракино", NotificationManager.IMPORTANCE_LOW);
            getSystemService(NotificationManager.class).createNotificationChannel(ch);
        }
        PendingIntent pi = PendingIntent.getActivity(this, 0, new Intent(this, MainActivity.class),
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Notification.Builder b = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this, "terra") : new Notification.Builder(this);
        return b.setContentTitle("Терракино")
                .setContentText("Сервер библиотеки работает")
                .setSmallIcon(android.R.drawable.ic_media_play)
                .setOngoing(true)
                .setContentIntent(pi)
                .build();
    }

    /** Кладёт встроенный сайт (index.html, server.py...) в рабочую папку, откуда его запускает Python. */
    private void copyAssets() throws Exception {
        File dst = new File(getFilesDir(), "bundled");
        dst.mkdirs();
        String[] names = getAssets().list("site");
        if (names == null) return;
        for (String name : names) {
            try (InputStream in = getAssets().open("site/" + name);
                 OutputStream out = new FileOutputStream(new File(dst, name))) {
                byte[] buf = new byte[65536];
                int r;
                while ((r = in.read(buf)) > 0) out.write(buf, 0, r);
            }
        }
    }

    @Override
    public void onDestroy() {
        h.removeCallbacks(tick);
        if (wl != null && wl.isHeld()) wl.release();
        super.onDestroy();
    }
}
