package ru.terrakino.app;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.net.Uri;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.chaquo.python.PyObject;
import com.chaquo.python.Python;

import org.json.JSONObject;

import java.io.File;

/** Один экран: WebView с сайтом, который отдаёт Python-сервер внутри приложения. */
public class MainActivity extends Activity {
    static final int PORT = 8765;
    static final String HOME = "http://127.0.0.1:" + PORT + "/";
    private static final int REQ_FILE = 11, REQ_NOTIF = 12, REQ_STORAGE = 13;
    private static final String BG = "#F6EFE6";

    private final Handler ui = new Handler(Looper.getMainLooper());
    private FrameLayout root;
    private WebView web;
    private TextView splash;
    private ValueCallback<Uri[]> fileCb;
    private View customView;
    private WebChromeClient.CustomViewCallback customCb;
    private boolean pageLoaded = false, dialogOpen = false, lightBars = true;
    private int offered = 0, retries = 0;
    private boolean switching = false, askedNow = false;

    private PyObject runner() {
        return Python.getInstance().getModule("runner");
    }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        root = new FrameLayout(this);
        root.setBackgroundColor(Color.parseColor(BG));

        web = new WebView(this);
        web.setBackgroundColor(Color.parseColor(BG));
        web.setVisibility(View.INVISIBLE);
        root.addView(web, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        splash = new TextView(this);
        splash.setText("Терракино\nзапускаю сервер…");
        splash.setTextColor(Color.parseColor("#7A4A32"));
        splash.setTextSize(20);
        splash.setGravity(Gravity.CENTER);
        root.addView(splash, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        setContentView(root);

        setupWeb();
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTIF);
        }
        startServer();
    }

    private void startServer() {
        Intent i = new Intent(this, ServerService.class);
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i);
        else startService(i);

        new Thread(() -> {
            long end = System.currentTimeMillis() + 120000;
            while (System.currentTimeMillis() < end && !ServerService.ready && ServerService.error.isEmpty()) {
                try {
                    Thread.sleep(250);
                } catch (InterruptedException ignored) {
                }
            }
            final boolean ok = ServerService.ready;
            ui.post(() -> {
                if (ok) {
                    web.loadUrl(HOME);
                } else {
                    String e = ServerService.error.isEmpty() ? "сервер не запустился за 2 минуты" : ServerService.error;
                    splash.setText("Не удалось запустить сервер\n\n" + e);
                    splash.setTextSize(14);
                }
            });
        }).start();
    }

    private void setupWeb() {
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(true);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        web.addJavascriptInterface(new Bridge(), "AndroidApp");

        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                if (r.getUrl().toString().startsWith(HOME)) return false;
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, r.getUrl()));
                } catch (Exception ignored) {
                }
                return true;
            }

            @Override
            public void onPageFinished(WebView v, String url) {
                if (url == null || !url.startsWith(HOME)) return;
                pageLoaded = true;
                retries = 0;
                maybeAskStorage();
                web.setVisibility(View.VISIBLE);
                splash.setVisibility(View.GONE);
                // пока играет видео, экран не гаснет
                v.evaluateJavascript("(function(){if(window.__ak)return;window.__ak=1;"
                        + "var f=function(on){return function(){try{AndroidApp.keepOn(on)}catch(e){}}};"
                        + "document.addEventListener('play',f(true),true);"
                        + "document.addEventListener('pause',f(false),true);"
                        + "document.addEventListener('ended',f(false),true)})()", null);
                offerUpdate(false);
            }

            @Override
            public void onReceivedError(WebView v, WebResourceRequest r, WebResourceError e) {
                if (r.isForMainFrame() && retries < 10) {
                    retries++;
                    ui.postDelayed(() -> web.loadUrl(HOME), 1000);
                }
            }
        });
        web.setWebChromeClient(chrome);
    }

    private final WebChromeClient chrome = new WebChromeClient() {
        @Override
        public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams p) {
            if (fileCb != null) fileCb.onReceiveValue(null);
            fileCb = cb;
            try {
                startActivityForResult(p.createIntent(), REQ_FILE);
            } catch (Exception e) {
                fileCb = null;
                return false;
            }
            return true;
        }

        @Override
        public void onShowCustomView(View v, CustomViewCallback cb) {
            if (customView != null) {
                cb.onCustomViewHidden();
                return;
            }
            customView = v;
            customCb = cb;
            root.addView(v, new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
            web.setVisibility(View.GONE);
            immersive(true);
        }

        @Override
        public void onHideCustomView() {
            if (customView == null) return;
            root.removeView(customView);
            customView = null;
            if (customCb != null) customCb.onCustomViewHidden();
            customCb = null;
            web.setVisibility(View.VISIBLE);
            immersive(false);
        }

        @Override
        public Bitmap getDefaultVideoPoster() {
            return Bitmap.createBitmap(1, 1, Bitmap.Config.ARGB_8888);
        }
    };

    private int barFlags() {
        int f = 0;
        if (lightBars) {
            f |= View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
            if (Build.VERSION.SDK_INT >= 26) f |= View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
        }
        return f;
    }

    private void immersive(boolean on) {
        View d = getWindow().getDecorView();
        if (on) {
            d.setSystemUiVisibility(View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                    | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
        } else {
            d.setSystemUiVisibility(barFlags());
        }
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        if (req == REQ_FILE) {
            if (fileCb != null) {
                fileCb.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(res, data));
                fileCb = null;
            }
            return;
        }
        super.onActivityResult(req, res, data);
    }

    @Override
    public void onBackPressed() {
        if (customView != null) {
            chrome.onHideCustomView();
            return;
        }
        web.evaluateJavascript("(function(){var s=document.getElementById('sh');"
                + "if(s&&s.classList.contains('open')){closeD();return 1}return 0})()", v -> {
            if (!"1".equals(v)) moveTaskToBack(true); // сворачиваем, а не закрываем: сервер продолжает работать
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        checkRoot();
        offerUpdate(false);
    }

    @Override
    public void onRequestPermissionsResult(int req, String[] perms, int[] res) {
        super.onRequestPermissionsResult(req, perms, res);
        if (req == REQ_STORAGE) checkRoot();
    }

    // ---------- перенос файлов из «Загрузок» вместо копирования ----------

    private void maybeAskStorage() {
        SharedPreferences sp = getSharedPreferences("terra", MODE_PRIVATE);
        if (askedNow || ServerService.hasAllFiles(this) || sp.getBoolean("asked_storage", false)) return;
        askedNow = true;
        sp.edit().putBoolean("asked_storage", true).apply();
        new AlertDialog.Builder(this)
                .setTitle("Мгновенный перенос серий")
                .setMessage("Если разрешить доступ к файлам, серии из «Загрузок» будут не копироваться, а переноситься: "
                        + "быстро и без двойного места. Видео будут лежать в папке Terrakino и не пропадут при удалении приложения.")
                .setPositiveButton("Разрешить", (d, w) -> requestAllFiles())
                .setNegativeButton("Не сейчас", null)
                .show();
    }

    private void requestAllFiles() {
        if (Build.VERSION.SDK_INT >= 30) {
            try {
                startActivity(new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                        Uri.parse("package:" + getPackageName())));
            } catch (Exception e) {
                try {
                    startActivity(new Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION));
                } catch (Exception ignored) {
                }
            }
        } else {
            requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE,
                    Manifest.permission.READ_EXTERNAL_STORAGE}, REQ_STORAGE);
        }
    }

    /** После выдачи доступа переключаем сервер на папку Terrakino и переносим туда уже добавленное. */
    private void checkRoot() {
        if (!ServerService.ready || switching) return;
        final File want = ServerService.libraryRoot(this);
        if (want.getAbsolutePath().equals(ServerService.root)) return;
        switching = true;
        splash.setText("Переношу библиотеку…");
        splash.setVisibility(View.VISIBLE);
        web.setVisibility(View.INVISIBLE);
        new Thread(() -> {
            boolean ok = false;
            try {
                runner().callAttr("restart", want.getAbsolutePath());
                ServerService.root = want.getAbsolutePath();
                ok = true;
            } catch (Throwable ignored) {
            }
            final boolean f = ok;
            ui.post(() -> {
                switching = false;
                if (f) {
                    web.clearCache(true);
                    web.loadUrl(HOME);
                    Toast.makeText(this, "Мгновенный перенос включён", Toast.LENGTH_LONG).show();
                } else {
                    splash.setVisibility(View.GONE);
                    web.setVisibility(View.VISIBLE);
                    Toast.makeText(this, "Не удалось сменить папку", Toast.LENGTH_LONG).show();
                }
            });
        }).start();
    }

    // ---------- обновление сайта ----------

    private void offerUpdate(boolean force) {
        if (!pageLoaded || dialogOpen) return;
        new Thread(() -> {
            try {
                JSONObject j = new JSONObject(runner().callAttr("status").toString());
                final int nv = j.optInt("new");
                if (j.optBoolean("ready") && (force || nv != offered)) ui.post(() -> showUpdate(nv));
            } catch (Throwable ignored) {
            }
        }).start();
    }

    private void showUpdate(int nv) {
        if (dialogOpen || isFinishing()) return;
        dialogOpen = true;
        offered = nv;
        new AlertDialog.Builder(this)
                .setTitle("Обновление готово")
                .setMessage("Скачана новая версия сайта (v" + nv + "). Применить сейчас?")
                .setPositiveButton("Применить", (d, w) -> applyUpdate())
                .setNegativeButton("Позже", null)
                .setOnDismissListener(d -> dialogOpen = false)
                .show();
    }

    private void applyUpdate() {
        Toast.makeText(this, "Применяю обновление…", Toast.LENGTH_SHORT).show();
        new Thread(() -> {
            boolean ok = false;
            try {
                ok = runner().callAttr("apply_update").toBoolean();
            } catch (Throwable ignored) {
            }
            final boolean f = ok;
            ui.post(() -> {
                if (f) {
                    web.clearCache(true);
                    web.loadUrl(HOME);
                    Toast.makeText(this, "Готово", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(this, "Не удалось применить обновление", Toast.LENGTH_LONG).show();
                }
            });
        }).start();
    }

    /** То, что сайт может вызывать через window.AndroidApp. */
    private class Bridge {
        @JavascriptInterface
        public String info() {
            try {
                JSONObject j = new JSONObject(runner().callAttr("status").toString());
                return "Приложение 1.0 · сайт v" + j.optInt("running");
            } catch (Throwable t) {
                return "Приложение 1.0";
            }
        }

        @JavascriptInterface
        public void checkUpdate() {
            new Thread(() -> {
                String m;
                try {
                    m = runner().callAttr("check_update").toString();
                } catch (Throwable t) {
                    m = "Ошибка проверки";
                }
                final String msg = m;
                ui.post(() -> {
                    Toast.makeText(MainActivity.this, msg, Toast.LENGTH_LONG).show();
                    offerUpdate(true);
                });
            }).start();
        }

        @JavascriptInterface
        public String storageMode() {
            return ServerService.hasAllFiles(MainActivity.this) ? "fast" : "copy";
        }

        @JavascriptInterface
        public void askStorage() {
            ui.post(() -> requestAllFiles());
        }

        @JavascriptInterface
        public String deviceId() {
            try {
                String id = Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID);
                return id == null || id.length() < 6 ? "" : "a" + id;
            } catch (Throwable t) {
                return "";
            }
        }

        @JavascriptInterface
        public void keepOn(boolean on) {
            ui.post(() -> web.setKeepScreenOn(on));
        }

        @JavascriptInterface
        public void bars(String bg, boolean dark) {
            ui.post(() -> {
                try {
                    int c = Color.parseColor(bg);
                    getWindow().setStatusBarColor(c);
                    getWindow().setNavigationBarColor(c);
                    root.setBackgroundColor(c);
                    web.setBackgroundColor(c);
                    lightBars = !dark;
                    if (customView == null) getWindow().getDecorView().setSystemUiVisibility(barFlags());
                } catch (Exception ignored) {
                }
            });
        }
    }
}
