"""Запуск сервера Терракино внутри приложения + обновление сайта «по воздуху» из GitHub."""
import ast
import importlib.util
import json
import os
import shutil
import threading
import time
import traceback
import urllib.request

S = {"httpd": None, "mod": None, "running": 0, "src": "", "ready": False, "new": 0,
     "err": "", "files": "", "port": 8765}
_lock = threading.RLock()
_seq = [0]


def _dir(name):
    return os.path.join(S["files"], name)


def _ver(d):
    try:
        if not (os.path.isfile(os.path.join(d, "server.py")) and os.path.isfile(os.path.join(d, "index.html"))):
            return 0
        with open(os.path.join(d, "version.txt")) as f:
            return int(f.read().strip())
    except Exception:
        return 0


def _probe(port):
    last = None
    for _ in range(25):
        try:
            with urllib.request.urlopen("http://127.0.0.1:%d/" % port, timeout=5) as r:
                body = r.read(200000)
                if r.status == 200 and b"<html" in body.lower():
                    return
                last = "bad response"
        except Exception as e:
            last = e
        time.sleep(0.2)
    raise RuntimeError("сервер не отвечает: %s" % last)


def _stop(httpd):
    try:
        httpd.shutdown()
        httpd.server_close()
    except Exception:
        pass


def _boot(d):
    os.environ["TERRA_APP"] = d
    _seq[0] += 1
    spec = importlib.util.spec_from_file_location("terra_server_%d" % _seq[0], os.path.join(d, "server.py"))
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    made = []  # все серверы, которые успел создать код обновления (чтобы освободить порт при сбое)
    base = mod.ThreadingHTTPServer

    class Rec(base):
        def __init__(self, *a, **k):
            super().__init__(*a, **k)
            made.append(self)

    mod.ThreadingHTTPServer = Rec
    try:
        httpd = mod.start_server()
        _probe(S["port"])
    except Exception:
        for h in made:
            threading.Thread(target=h.shutdown, daemon=True).start()
            try:
                h.server_close()
            except Exception:
                pass
        time.sleep(0.3)
        raise
    S.update(httpd=httpd, mod=mod, running=_ver(d), src=os.path.basename(d))


def _order():
    b, l = _dir("bundled"), _dir("live")
    if _ver(l) > _ver(b):
        return [l, b]
    shutil.rmtree(l, ignore_errors=True)  # встроенная версия новее или такая же
    return [b]


def start(root, files_dir, port=8765):
    with _lock:
        S.update(files=files_dir, port=int(port))
        os.makedirs(root, exist_ok=True)
        os.environ["TERRA_ROOT"] = root
        os.environ["TERRA_PORT"] = str(int(port))
        S["err"] = ""
        booted = False
        for d in _order():
            try:
                _boot(d)
                booted = True
                break
            except Exception:
                S["err"] = traceback.format_exc()
                if d == _dir("live"):
                    shutil.rmtree(d, ignore_errors=True)  # битое обновление выбрасываем
        if not booted:
            raise RuntimeError(S["err"])
    threading.Thread(target=_loop, daemon=True).start()


def _base():
    try:
        with open(os.path.join(_dir("bundled"), "config.json"), encoding="utf-8") as f:
            b = json.load(f).get("update_base", "")
        return b if b.startswith("https://") and "__REPO__" not in b else ""
    except Exception:
        return ""


def _get(url):
    req = urllib.request.Request(url + "?t=%d" % int(time.time()),
                                 headers={"User-Agent": "Terrakino", "Cache-Control": "no-cache"})
    with urllib.request.urlopen(req, timeout=25) as r:
        return r.read(8 * 1024 * 1024)


def check_update():
    """Возвращает текст для пользователя. Скачивает обновление, но не применяет его."""
    base = _base()
    if not base:
        return "Обновления не настроены"
    try:
        remote = int(_get(base + "version.txt").decode().strip())
    except Exception:
        return "Не удалось проверить: нет доступа к GitHub"
    cur = max(S["running"], _ver(_dir("live")))
    if remote <= cur:
        return "У вас последняя версия (%d)" % cur
    try:
        idx, srv = _get(base + "index.html"), _get(base + "server.py")
        text = srv.decode("utf-8")
        compile(text, "server.py", "exec")
        ast.parse(text)
        if "def start_server(" not in text or len(srv) < 5000 or b"<html" not in idx.lower() or len(idx) < 5000:
            return "Файлы обновления выглядят неполными, обновление пропущено"
        tmp = _dir("live_tmp")
        shutil.rmtree(tmp, ignore_errors=True)
        os.makedirs(tmp)
        for name, data in (("index.html", idx), ("server.py", srv), ("version.txt", str(remote).encode())):
            with open(os.path.join(tmp, name), "wb") as f:
                f.write(data)
        with _lock:
            shutil.rmtree(_dir("live"), ignore_errors=True)
            os.replace(tmp, _dir("live"))
            S["ready"], S["new"] = True, remote
        return "Скачано обновление: версия %d" % remote
    except Exception as e:
        return "Ошибка обновления: %s" % str(e)[:80]


def apply_update():
    with _lock:
        if not S["ready"]:
            return False
        _stop(S["httpd"])
        try:
            _boot(_dir("live"))
        except Exception:
            S["err"] = traceback.format_exc()
            shutil.rmtree(_dir("live"), ignore_errors=True)
            _boot(_dir("bundled"))  # откат на встроенную версию
        S["ready"] = False
        return True


def _loop():
    time.sleep(8)
    while True:
        try:
            check_update()
        except Exception:
            pass
        time.sleep(6 * 3600)


def status():
    return json.dumps({"running": S["running"], "src": S["src"], "ready": S["ready"],
                       "new": S["new"], "err": S["err"][-300:]})


def busy():
    try:
        return any(j["state"] in ("queued", "run") for j in list(S["mod"].JOBS.values()))
    except Exception:
        return False
